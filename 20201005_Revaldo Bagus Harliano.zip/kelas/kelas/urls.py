from django.contrib import admin
from django.urls import path
from django.http import HttpResponse
from django.shortcuts import render
from dashboard.views import produk, tambah_barang, Barang_View,Karyawan_View,Order_View

def coba1(request):
    return HttpResponse('Hello Felas...')
def coba2(request):
    titelnya="Home"
    konteks = {
        'titel':titelnya,
    }
    return render (request,'index.html',konteks)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',coba2),
    path('produk/',produk),
    path('addbrng/',tambah_barang),
    path('Vbrg/',Barang_View,name='barang_view'),
    path('Vbrg2/',Karyawan_View,name='karyawan_view'),
    path('Vbrg3/',Order_View,name='order_view'),
]
