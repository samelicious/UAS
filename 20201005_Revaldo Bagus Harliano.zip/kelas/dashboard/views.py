from django.shortcuts import render
from dashboard.form import FormBarang
from dashboard.models import Barang,Karyawan,Order
# Create your views here.
def Barang_View(request):
    barangs=Barang.objects.all()

    konteks={
        'barangs':barangs
    }
    return render(request,'tampil_brg.html',konteks)

def Karyawan_View(request):
    karyawans=Karyawan.objects.all()

    konteks={
        'karyawans':karyawans
        }
    return render(request,'tampil_brg2.html',konteks)

def Order_View(request):
    orders=Order.objects.all()

    konteks={
        'orders':orders
    }
    return render(request,'tampil_brg3.html',konteks)

def tambah_barang(request):
    form=FormBarang()
    konteks={
        'form':form,
    }
    return render(request,'tambah_barang.html',konteks)

def produk (request):
    titelnya="Produk"
    konteks = {
        'titel':titelnya,
    }
    return render(request,'produk.html',konteks)